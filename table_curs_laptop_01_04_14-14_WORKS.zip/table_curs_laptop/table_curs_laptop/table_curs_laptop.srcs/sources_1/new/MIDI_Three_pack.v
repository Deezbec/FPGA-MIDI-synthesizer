`timescale 1ns / 1ps

module MIDI_Three_pack # (MIDI_CLK_DIV = 3200)(
    input clk,
    input MIDI_dat,
    output reg [4:0] note_press,
    output reg [7:0] note_volume,
    output reg [2:0] ERROR,
    //--------------- FPGA DEBUG ------------------------------
    //output [7:0] pack,
    //output R_O_pack,
    //--------------- FPGA DEBUG ------------------------------
    output R_O
    );
wire [7:0] pack;
wire R_O_pack;
wire ERROR_pack;

reg [7:0] pack_serv;
reg [2:0] pack_cnt;
reg send, read, read_upd;
//reg skip;

initial
begin
    pack_serv = 0;
    note_press = 0;
    note_volume = 0;
    ERROR = 0;
    pack_cnt = 3'b000;
    read = 0;
    //skip = 0;
    send = 0;
    read_upd = 0;
end

assign R_O = &pack_cnt & send & (pack_serv == 16'h90);

/*
always@(R_O_pack) begin
    if (R_O_pack) skip <= 1'b1;
    else skip <= 0;
end
//*/

always@(posedge MIDI_clk) begin
    //if (R_O_pack & skip) begin
    if (R_O_pack) begin
        pack_cnt <= (&pack_cnt)? 3'b100 : {1'b1, pack_cnt[2:1]};
        read <= 1'b0;
    end
    else read <= 1'b1;
end

always@(posedge clk)
begin
    //if (R_O_pack) begin
        send <= 0;
        if (&pack_cnt) begin 
            ERROR <= 3'b000;
        end
        if (~read) begin
            case(pack_cnt)
                3'b100: begin
                    if (ERROR_pack) ERROR[0] <= 1'b1;
                    pack_serv <= pack;
                end
                3'b110: begin
                    if (ERROR_pack) ERROR[1] <= 1'b1;
                    note_press <= {~pack[4], pack[3:0]};
                end
                3'b111: begin
                    if (ERROR_pack) ERROR[2] <= 1'b1;
                    note_volume <= pack;
                    send <= 1;
                end
            endcase
            
        end
    //end
end
 
clk_div #(
    .DIV_VAL(MIDI_CLK_DIV)  
) clk_div_inst (
    .clk(clk),
    .clk_out(MIDI_clk)
);

MIDI_design uut(
    .clk(clk),
    .MIDI_clk(MIDI_clk),
    .MIDI_dat(MIDI_dat),
    .out(pack),
    .R_O(R_O_pack),
    .ERROR(ERROR_pack)
);

endmodule
