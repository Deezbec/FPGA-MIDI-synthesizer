`timescale 1ns / 1ps

module MIDI_design(
    input clk,
    input MIDI_clk,
    input MIDI_dat,
    output [7:0] out,
    output reg R_O,
    output reg ERROR
);

parameter WAIT_START_BIT = 0,
          WRITE = 1,
          STOP_BIT = 2;

reg [1:0] state;
reg [2:0] cnt;
reg [7:0] MIDI_buf;
reg [1:0] MIDI_clk_sync, MIDI_dat_sync;

assign out = MIDI_buf;

initial
begin
    cnt = 0;
    R_O = 0;
    ERROR = 0;
    state = WAIT_START_BIT;
    MIDI_buf = 0;
    MIDI_clk_sync = 2'b11;
    MIDI_dat_sync = 2'b11;
end

always@(posedge clk)
begin
    //if (R_O) R_O <= 1'b0;
    //else if (state == STOP_BIT) R_O <= 1'b1;
    MIDI_clk_sync <= {MIDI_clk_sync[0], MIDI_clk};
    MIDI_dat_sync <= {MIDI_dat_sync[0], MIDI_dat};
end

always@(negedge MIDI_clk_sync[1])
begin
    case(state)
        WAIT_START_BIT: begin
            R_O <= 0;
            ERROR <= 0;
            if (~MIDI_dat_sync[1]) 
                state <= WRITE;
        end
        WRITE: begin
            MIDI_buf <= {MIDI_buf[6:0], MIDI_dat_sync[1]};
            if (cnt == 4'd7) begin 
                state <= STOP_BIT; 
                cnt <= 0;
            end else begin cnt <= cnt + 1; end
        end
        STOP_BIT: begin
            if (!MIDI_dat_sync[1])
                ERROR <= 1;
            R_O <= 1;
            state <= WAIT_START_BIT;
        end
    endcase
end

endmodule