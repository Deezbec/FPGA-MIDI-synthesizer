`timescale 1ns / 1ps

module top(
    input clk,
    input reset,
    input MIDI_dat,
    output reg pwm_out
    );

localparam SOUND_BITS_NUM = 33,
           MAX_NOTES_NUM = 5,
           //MIDI_CLK_DIV = 4, // 3200 - 100 ���
           // DIV = f_clk / f_midi = 10 * 1'000'000 / 31250 = 320
           MIDI_CLK_DIV = 320, // 320 - 10 ���
           MIDI_BIT_HOLD = MIDI_CLK_DIV * 10,
           MAX_SUM_OPERATIONS = 16,
           MAX_SUM_OPERATIONS_CLOG = $clog2(MAX_SUM_OPERATIONS);

/*
task automatic calculate_operations;
    input integer A;
    output integer operations;
    integer items;
    integer power;
begin
    operations = 0;
    items = A;
    
    while (items > 1) begin
        power = 1;
        while (power * 2 <= items) begin
            power = power * 2;
        end
        items = items - power + 1;
        operations = operations + 1;
    end
end
endtask
reg [MAX_SUM_OPERATIONS_CLOG - 1:0] max_operations;
initial begin 
    calculate_operations(MAX_NOTES_NUM, max_operations); 
end
*/
           
wire signed [SOUND_BITS_NUM-1:0] sound;
wire pwm_out; // ����

audio_pwm #(
    .INPUT_WIDTH(SOUND_BITS_NUM),   
    .PWM_RESOLUTION(10)   
) pwm (
    .clk(clk),                      
    .reset(reset),
    .audio_in(sound),  
    .pwm_out(pwm_out)
);

wire [4:0] note_press;
wire [7:0] note_volume;
wire [1:0] ERROR_three_pack;
wire R_O_three_pack;

note_pusher#(
.SOUND_BITS_NUM(SOUND_BITS_NUM),
.MAX_NOTES_NUM(MAX_NOTES_NUM)
//.MAX_SUM_OPERATIONS_CLOG(MAX_SUM_OPERATIONS_CLOG)
) uut2 (
    .clk(clk),
    .note_press(note_press),
    .note_volume(note_volume),
    .R_O_three_pack(R_O_three_pack),
    //.max_sum_operations(max_operations),
    .sound(sound)
    );

wire MIDI_clk;
MIDI_Three_pack test3(
    .clk(clk),
    .MIDI_clk(MIDI_clk),
    .MIDI_dat(MIDI_dat),
    .note_press(note_press),
    .note_volume(note_volume),
    .ERROR(ERROR_three_pack),
    .R_O(R_O_three_pack)
    );

clk_div #(
    .DIV_VAL(MIDI_CLK_DIV)  
) clk_div_inst (
    .clk(clk),
    .clk_out(MIDI_clk)
);

wire [7:0] pack;
wire R_O_pack;
wire ERROR_pack;
MIDI_design des_unit(
    .clk(clk),
    .MIDI_clk(MIDI_clk),
    .MIDI_dat(MIDI_dat),
    .out(pack),
    .R_O(R_O_pack),
    .ERROR(ERROR_pack)
);

endmodule
