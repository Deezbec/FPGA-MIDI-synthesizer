`timescale 1ns / 1ps

module note_pusher # (
parameter SOUND_BITS_NUM = 33,
parameter MAX_NOTES_NUM = 5
//parameter MAX_SUM_OPERATIONS_CLOG = 4
) (
    input clk,
    input [4:0] note_press,
    input [7:0] note_volume,
    input R_O_three_pack,
    //input [MAX_SUM_OPERATIONS_CLOG - 1:0] max_sum_operations,
    output [SOUND_BITS_NUM-1:0] sound
    );

localparam TABLE_VALUE_WIDTH = 33,
//localparam TABLE_VALUE_WIDTH = 43,
           TABLE_ANGLE_WIDTH = 10,
           COUNT = 2**TABLE_ANGLE_WIDTH,
           //MAX_NOTES_NUM = 5,
           MAX_NOTES_NUM_CLOG = $clog2(MAX_NOTES_NUM),
           SYNTHESISED_NOTES_AMOUNT = 24,
           SYNTHESISED_NOTES_AMOUNT_CLOG = $clog2(SYNTHESISED_NOTES_AMOUNT);

reg signed [MAX_NOTES_NUM_CLOG - 1:0] active_notes_num;
reg [MAX_NOTES_NUM - 1:0] active_notes_mask;
reg [SYNTHESISED_NOTES_AMOUNT - 1:0] active_notes;

initial begin
    active_notes_num = 0;
    active_notes = 0;
    active_notes_mask = 0;
end
/*
reg R_O_three_pack_sync;
always @(posedge clk) begin
    R_O_three_pack_sync <= R_O_three_pack;
end
//*/
always @(posedge R_O_three_pack) begin
    //if (R_O_three_pack_sync) begin
        if (note_volume == 8'd0) begin
            active_notes[note_press] <= 0;
            active_notes_num <= active_notes_num - 1;
            active_notes_mask <= {1'b0, {active_notes_mask[MAX_NOTES_NUM - 1:1]}};
        //end else if(active_notes_num < 3'b110) begin
        end else if(active_notes_num < MAX_NOTES_NUM) begin
            active_notes[note_press] <= 1;
            active_notes_num <= active_notes_num + 1;
            active_notes_mask <= {{active_notes_mask[MAX_NOTES_NUM - 2:0]}, 1'b1};
        end
    //end
end

/*
genvar idx, note_idx;
wire [SYNTHESISED_NOTES_AMOUNT_CLOG-1:0] note_press_mass_comb [0:MAX_NOTES_NUM-1];
reg [SYNTHESISED_NOTES_AMOUNT_CLOG - 1:0] note_press_mass [MAX_NOTES_NUM - 1:0];
generate
    for (note_idx = 0; note_idx < MAX_NOTES_NUM; note_idx = note_idx + 1) begin
        assign note_press_mass_comb[note_idx] = 
            active_notes[note_idx] ? note_idx : 0;
    end
endgenerate
integer k;
always @(posedge clk) begin
    for(k = 0; k < MAX_NOTES_NUM; k = k + 1) begin
        note_press_mass[k] <= note_press_mass_comb[k];
    end
end
//*/
///*
reg [SYNTHESISED_NOTES_AMOUNT_CLOG - 1:0] note_press_mass [MAX_NOTES_NUM - 1:0];
integer i, j, k;
initial begin i = 0; j = 0; end
always@ (posedge clk) begin
    for(k = 0; k < MAX_NOTES_NUM; k = k + 1) begin
        note_press_mass[k] = 0;
    end
    for(i = 0; i < SYNTHESISED_NOTES_AMOUNT; i = i + 1) begin
        if (active_notes[i]) begin
            note_press_mass[j] = i;
            j = j + 1;
        end
    end
    i = 0; j = 0;
end
//*/

wire signed [TABLE_VALUE_WIDTH-1:0] sin [0:MAX_NOTES_NUM - 1];

//assign sound = (active_notes_num == 3'd0) ? 0 : ((sin[0] + sin[1] + sin[2] + sin[3] + sin[4] + sin[5]) / active_notes_num);
//assign sound = (active_notes_num == 3'd0) ? 0 : ((sin[0] + sin[1] + sin[2] + sin[3] + sin[4]) / active_notes_num);
/*
assign sound = (active_notes_num == 3'd0) ? 
                   0
              : (active_notes_num == 3'd1) ? 
                   sin[0]
              : (active_notes_num == 3'd2) ? 
                   (sin[0] + sin[1]) >>> 1
              : (active_notes_num == 3'd3) ? 
                   //(((sin[0] + sin[1]) >>> 1) + sin[2]) >>> 1
                   (sin[0] + sin[1] + sin[2]) * 341 >>> 10    // *0.3333 ������������
              : (active_notes_num == 3'd4) ? 
                   (sin[0] + sin[1] + sin[2] + sin[3]) >>> 2 
              //: (((sin[0] + sin[1] + sin[2] + sin[3]) >>> 2) + sin[4]) >>> 1;
              : (sin[0] + sin[1] + sin[2] + sin[3] + sin[4]) * 205 >>> 10;  // *0.2
//*/
///*
reg signed [SOUND_BITS_NUM+10:0] sum_temp;
reg signed [SOUND_BITS_NUM-1:0] sound_reg;

always @(posedge clk) begin
    case (active_notes_num)
        0: sound_reg <= 0;
        1: sound_reg <= sin[0];
        2: sound_reg <= (sin[0] + sin[1]) >>> 1;
        3: begin
            sum_temp = sin[0] + sin[1] + sin[2];
            sound_reg <= (sum_temp * 341) >>> 10;
        end
        4: sound_reg <= (sin[0] + sin[1] + sin[2] + sin[3]) >>> 2;
        default: begin
            sum_temp = sin[0] + sin[1] + sin[2] + sin[3] + sin[4];
            sound_reg <= (sum_temp * 205) >>> 10;
        end
    endcase
end

assign sound = sound_reg;
//*/

///*
genvar i_gen0;
generate
    for (i_gen0 = 0; i_gen0 < MAX_NOTES_NUM; i_gen0 = i_gen0 + 1) begin : gen_sin
        sin_gen_acc #(
            .sin_num(i_gen0),
            .TABLE_VALUE_WIDTH(TABLE_VALUE_WIDTH),
            .TABLE_ANGLE_WIDTH(10)
        ) uut (
            .clk(clk),
            .note_press(note_press_mass[i_gen0]),
            .off(~active_notes_mask[i_gen0]),
            .trig_table_sin(sin[i_gen0])
        );
    end
endgenerate
//*/
/*
genvar i_gen0;
generate
    for (i_gen0 = 0; i_gen0 < MAX_NOTES_NUM; i_gen0 = i_gen0 + 1) begin : gen_sin
        sin_gen #(
            .sin_num(i_gen0),
            .TABLE_VALUE_WIDTH(TABLE_VALUE_WIDTH),
            .TABLE_ANGLE_WIDTH(10)
        ) uut (
            .clk(clk),
            .note_press(note_press_mass[i_gen0]),
            .off(~active_notes_mask[i_gen0]),
            .trig_table_sin(sin[i_gen0])
        );
    end
endgenerate
//*/

endmodule