`timescale 1ns / 1ps

module MIDI_Three_pack(
    input clk,
    input MIDI_clk,
    input MIDI_dat,
    output reg [4:0] note_press,
    output reg [7:0] note_volume,
    output reg [1:0] ERROR,
    output reg R_O
    );
wire [7:0] pack;
wire R_O_pack;
wire ERROR_pack;

parameter WAIT_90_PACK = 0,
          WRITE_NOTE = 1,
          WRITE_VOLUME = 2;

reg [1:0] state;

initial
begin
    state = WAIT_90_PACK;
    ERROR = 2'b00;
    note_volume = 16'hAA;
    note_press = 6'd0;
    R_O = 0;
end

/*
always@(posedge clk)
begin
    if (R_O) R_O <= 1'b0;
    else if (state == WRITE_VOLUME) R_O <= 1'b1;
end
//*/

always@(posedge R_O_pack)
begin
    case(state)
        WAIT_90_PACK: begin
            R_O <= 1'b0;
            if (ERROR_pack) begin
                ERROR <= 2'b01;
                state <= WAIT_90_PACK;
            end else begin
                ERROR <= 0;
                state <= (pack == 16'h90) ? WRITE_NOTE : WAIT_90_PACK;
            end
        end

        WRITE_NOTE: begin
                note_press <= {~pack[4], pack[3:0]};
                state <= WRITE_VOLUME;
            end

        WRITE_VOLUME: begin
            note_volume <= pack;
            R_O <= 1'b1;
            state <= WAIT_90_PACK;
        end
    endcase
end
 

MIDI_design uut(
    .clk(clk),
    .MIDI_clk(MIDI_clk),
    .MIDI_dat(MIDI_dat),
    .out(pack),
    .R_O(R_O_pack),
    .ERROR(ERROR_pack)
);

endmodule
