`timescale 1ns / 1ps


module test_top(
    input clk,
    output pwm_out
    );

reg MIDI_dat_gen;
wire MIDI_dat;
assign MIDI_dat = MIDI_dat_gen;

localparam CLK_CH_FROM_100 = 2,
           MIDI_CLK_DIV = 4,
           MIDI_CLK_DIV_WIDTH = $clog2(MIDI_CLK_DIV),
           MIDI_BIT_HOLD = MIDI_CLK_DIV * 10 * CLK_CH_FROM_100,
           MIDI_WAIT_FOR_BUF = MIDI_BIT_HOLD * 4;

task gen_midi_three_pack;
    input [7:0] status;   
    input [7:0] note;  
    input [7:0] velocity; 
    integer i;
begin
    MIDI_dat_gen = 0; #MIDI_BIT_HOLD; 
    for (i = 7; i >= 0; i = i - 1) begin
        MIDI_dat_gen = status[i]; #MIDI_BIT_HOLD;
    end
    MIDI_dat_gen = 1; #MIDI_BIT_HOLD; 
    
    MIDI_dat_gen = 0; #MIDI_BIT_HOLD; 
    for (i = 7; i >= 0; i = i - 1) begin
        MIDI_dat_gen = note[i]; #MIDI_BIT_HOLD;
    end
    MIDI_dat_gen = 1; #MIDI_BIT_HOLD; 
    
    MIDI_dat_gen = 0; #MIDI_BIT_HOLD; 
    for (i = 7; i >= 0; i = i - 1) begin
        MIDI_dat_gen = velocity[i]; #MIDI_BIT_HOLD; 
    end
    MIDI_dat_gen = 1; #MIDI_BIT_HOLD; 
end
endtask

reg reset;
localparam timewait = 10000000; 
localparam timewait_half = 5000000; 
initial begin
    reset = 1'b0;
    
    ///*
    gen_midi_three_pack(8'h90, 8'h10, 8'hAA); #timewait;
    gen_midi_three_pack(8'h90, 8'h12, 8'hAA); #timewait;
    gen_midi_three_pack(8'h90, 8'h1, 8'hAA); #timewait;
    gen_midi_three_pack(8'h90, 8'h5, 8'hAA); #timewait;
    gen_midi_three_pack(8'h90, 8'h20, 8'hAA); #timewait;
    
    gen_midi_three_pack(8'h90, 8'h3, 8'hAA); #timewait;
    
    gen_midi_three_pack(8'h90, 8'h1, 8'h00); #timewait;
    gen_midi_three_pack(8'h90, 8'h12, 8'h00); #timewait;
    gen_midi_three_pack(8'h90, 8'h20, 8'h00); #timewait;
    //*/
    
end
top uut(
    .clk(clk),
    .reset(reset),
    .MIDI_dat(MIDI_dat),
    .pwm_out(pwm_out)
    );


endmodule