`timescale 1ns / 1ps

module note_pusher # (
parameter SOUND_BITS_NUM = 33,
parameter MAX_NOTES_NUM = 5
) (
    input clk,
    input [4:0] note_press,
    input [7:0] note_volume,
    input R_O_three_pack,
    input [15:0] SW,
    //--------------- FPGA DEBUG ------------------------------
    output [15:0] LED_notes_active_check,
    output reg [MAX_NOTES_NUM - 1:0] active_notes_mask,
    //--------------- FPGA DEBUG ------------------------------
    output [SOUND_BITS_NUM-1:0] sound
    );

localparam TABLE_VALUE_WIDTH = 33,
           TABLE_ANGLE_WIDTH = 10,
           COUNT = 2**TABLE_ANGLE_WIDTH,
           MAX_NOTES_NUM_CLOG = $clog2(MAX_NOTES_NUM),
           SYNTHESISED_NOTES_AMOUNT = 24,
           SYNTHESISED_NOTES_AMOUNT_CLOG = $clog2(SYNTHESISED_NOTES_AMOUNT);

reg signed [MAX_NOTES_NUM_CLOG - 1:0] active_notes_num;
reg [MAX_NOTES_NUM - 1:0] active_notes_mask;
reg [SYNTHESISED_NOTES_AMOUNT - 1:0] active_notes;
reg [SYNTHESISED_NOTES_AMOUNT_CLOG - 1:0] note_press_mass [0:MAX_NOTES_NUM - 1];
reg [SYNTHESISED_NOTES_AMOUNT_CLOG - 1:0] k, m;
reg turn_offed_curr_flag;

initial begin
    active_notes_num = 0;
    active_notes = 0;
    active_notes_mask = 0;
    k = 0; m = 0;
    for(k = 0; k < MAX_NOTES_NUM; k = k + 1) begin
        note_press_mass[k] = 0;
    end
    turn_offed_curr_flag = 0;
end

//--------------- FPGA DEBUG ------------------------------
assign LED_notes_active_check = active_notes[15:0];
//--------------- FPGA DEBUG ------------------------------

always @(posedge clk) begin
    if (~SW[15]) begin
        if(R_O_three_pack) begin
            if (note_volume == 8'd0 & active_notes_num >= 0 & ~turn_offed_curr_flag) begin //active_notes[note_press] & 
                active_notes[note_press] <= 0;
                active_notes_num <= active_notes_num - 1;
                active_notes_mask <= {1'b0, {active_notes_mask[MAX_NOTES_NUM - 1:1]}};
                m = 0; 
                for(k = 0; k < SYNTHESISED_NOTES_AMOUNT; k = k + 1) begin 
                    if (active_notes[k] & m < MAX_NOTES_NUM) begin 
                        note_press_mass[m] <= (m < active_notes_num - 1) ? k : 0; 
                        m = m + 1; 
                    end 
                end
                turn_offed_curr_flag <= 1;
            end else begin 
                if(active_notes_num < MAX_NOTES_NUM & ~active_notes[note_press] & ~(note_volume == 8'd0)) begin //�������� �� ��������
                active_notes[note_press] <= 1;
                active_notes_num <= active_notes_num + 1;
                active_notes_mask <= {{active_notes_mask[MAX_NOTES_NUM - 2:0]}, 1'b1};
                note_press_mass[active_notes_num] <= note_press;
                end 
            end
        end
        else turn_offed_curr_flag <= 0;
    end else begin
        // ���������� ����� ����
    end
end


//-----------------------------------------------------------------------------------------

wire signed [TABLE_VALUE_WIDTH-1:0] sin [0:MAX_NOTES_NUM - 1];

//assign sound = (active_notes_num == 3'd0) ? 0 : ((sin[0] + sin[1] + sin[2] + sin[3] + sin[4] + sin[5]) / active_notes_num);
//assign sound = (active_notes_num == 3'd0) ? 0 : ((sin[0] + sin[1] + sin[2] + sin[3] + sin[4]) / active_notes_num);
/*
assign sound = (active_notes_num == 3'd0) ? 
                   0
              : (active_notes_num == 3'd1) ? 
                   sin[0]
              : (active_notes_num == 3'd2) ? 
                   (sin[0] + sin[1]) >>> 1
              : (active_notes_num == 3'd3) ? 
                   //(((sin[0] + sin[1]) >>> 1) + sin[2]) >>> 1
                   (sin[0] + sin[1] + sin[2]) * 341 >>> 10    // *0.3333 ������������
              : (active_notes_num == 3'd4) ? 
                   (sin[0] + sin[1] + sin[2] + sin[3]) >>> 2 
              //: (((sin[0] + sin[1] + sin[2] + sin[3]) >>> 2) + sin[4]) >>> 1;
              : (sin[0] + sin[1] + sin[2] + sin[3] + sin[4]) * 205 >>> 10;  // *0.2
//*/
///*
reg signed [SOUND_BITS_NUM+10:0] sum_temp;
reg signed [SOUND_BITS_NUM-1:0] sound_reg;
initial begin sum_temp = 0; sound_reg = 0; end

always @(posedge clk) begin
    case (active_notes_num)
        0: sound_reg <= 0;
        1: sound_reg <= sin[0];
        2: sound_reg <= (sin[0] + sin[1]) >>> 1;
        3: begin
            sum_temp = sin[0] + sin[1] + sin[2];
            sound_reg <= (sum_temp * 341) >>> 10;
        end
        4: sound_reg <= (sin[0] + sin[1] + sin[2] + sin[3]) >>> 2;
        default: begin
            sum_temp = sin[0] + sin[1] + sin[2] + sin[3] + sin[4];
            sound_reg <= (sum_temp * 205) >>> 10;
        end
    endcase
end

assign sound = sound_reg;
//*/

//-----------------------------------------------------------------------------------------

genvar i_gen0;
generate
    for (i_gen0 = 0; i_gen0 < MAX_NOTES_NUM; i_gen0 = i_gen0 + 1) begin : gen_sin
        sin_gen_acc #( 
        //sin_gen #( 
            .sin_num(i_gen0),
            .TABLE_VALUE_WIDTH(TABLE_VALUE_WIDTH),
            .TABLE_ANGLE_WIDTH(10)
        ) uut (
            .clk(clk),
            .note_press(note_press_mass[i_gen0]),
            .off(~active_notes_mask[i_gen0]),
            .trig_table_sin(sin[i_gen0])
        );
    end
endgenerate

endmodule