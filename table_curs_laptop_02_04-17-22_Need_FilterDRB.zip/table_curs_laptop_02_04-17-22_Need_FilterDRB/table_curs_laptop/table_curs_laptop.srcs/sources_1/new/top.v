`timescale 1ns / 1ps

module top# (MIDI_CLK_DIV = 3200)(
    input clk,
    input reset,
    input MIDI_dat,
    input [15:0] SW,
    output aud_en, // ������� 0
    //--------------- FPGA DEBUG ------------------------------
    ///*
    //output [9:0] LED_notes_active_check,
    //output MIDI_not_dat,
    //output R_O_three_pack,
    //output R_O_pack,
    //output [4:0] note_press,
    //output [4:0] active_notes_mask,
    //output [1:0] state,
    output [7:0] pack_note,
    output [7:0] pack_serv,
    //output [7:0] note_volume,
    //*/
    //--------------- FPGA DEBUG ------------------------------
    output reg pwm_out
    );
//--------------- FPGA DEBUG ------------------------------
wire MIDI_not_dat;
assign MIDI_not_dat = ~MIDI_dat;
//--------------- FPGA DEBUG ------------------------------

// MIDI_CLK_DIV = f_clk / f_midi = 10 * 1'000'000 / 31250 = 320
localparam SOUND_BITS_NUM = 33,
           MAX_NOTES_NUM = 5,
           MIDI_BIT_HOLD = MIDI_CLK_DIV * 10,
           MAX_SUM_OPERATIONS = 16,
           MAX_SUM_OPERATIONS_CLOG = $clog2(MAX_SUM_OPERATIONS);

/*
task automatic calculate_operations;
    input integer A;
    output integer operations;
    integer items;
    integer power;
begin
    operations = 0;
    items = A;
    
    while (items > 1) begin
        power = 1;
        while (power * 2 <= items) begin
            power = power * 2;
        end
        items = items - power + 1;
        operations = operations + 1;
    end
end
endtask
reg [MAX_SUM_OPERATIONS_CLOG - 1:0] max_operations;
initial begin 
    calculate_operations(MAX_NOTES_NUM, max_operations); 
end
*/

wire signed [SOUND_BITS_NUM-1:0] sound;
wire pwm_out; // ����
wire aud_en;
assign aud_en = 1'b0;

audio_pwm #(
    .INPUT_WIDTH(SOUND_BITS_NUM),   
    .PWM_RESOLUTION(10)   
) pwm (
    .clk(clk),                      
    .reset(reset),
    .audio_in(sound),  
    .pwm_out(pwm_out)
);

wire [4:0] note_press;
wire [7:0] note_volume;
wire [2:0] ERROR_three_pack;
wire R_O_three_pack;
wire R_O_pack;

wire [15:0] LED_notes_active_check;
wire [4:0] active_notes_mask;
note_pusher#(
.SOUND_BITS_NUM(SOUND_BITS_NUM),
.MAX_NOTES_NUM(MAX_NOTES_NUM)
) uut2 (
    .clk(clk),
    .note_press(note_press),
    .note_volume(note_volume),
    .R_O_three_pack(R_O_three_pack),
    .SW(SW),
    //--------------- FPGA DEBUG ------------------------------
    .LED_notes_active_check(LED_notes_active_check),
    .active_notes_mask(active_notes_mask),
    //--------------- FPGA DEBUG ------------------------------
    .sound(sound)
    );

clk_div #(
    .DIV_VAL(MIDI_CLK_DIV)  
) clk_div_inst (
    .clk(clk),
    .clk_out(MIDI_clk)
);

wire [7:0] pack;
wire [1:0] state;
MIDI_design uut(
    .clk(clk),
    .MIDI_clk(MIDI_clk),
    .MIDI_dat(MIDI_dat),
    .out(pack),
    .R_O(R_O_pack),
    //--------------- FPGA DEBUG ------------------------------
    //.state(state),
    //--------------- FPGA DEBUG ------------------------------
    .ERROR(ERROR_pack)
);

wire [7:0] pack_note, pack_serv;
MIDI_Three_pack #(MIDI_CLK_DIV) test3(
    .clk(clk),
    .MIDI_clk(MIDI_clk),
    .pack(pack),
    .R_O_pack(R_O_pack),
    .ERROR_pack(ERROR_pack),
    //.MIDI_dat(MIDI_not_dat),
    .note_press(note_press),
    .note_volume(note_volume),
    .ERROR(ERROR_three_pack),
    //--------------- FPGA DEBUG ------------------------------
    //.pack(pack_pre),
    .pack_note(pack_note),
    .pack_serv(pack_serv),
    //.R_O_pack(R_O_pack),
    //--------------- FPGA DEBUG ------------------------------
    .R_O(R_O_three_pack)
    );



endmodule
